import { createServer } from "node:http";
import next from "next";
import { Server } from "socket.io";
import { PrismaClient } from "@prisma/client";
import jwt from "jsonwebtoken";

const dev = process.env.NODE_ENV !== "production";
const hostname = "localhost";
const port = parseInt(process.env.PORT || "3000");
const app = next({ dev, hostname, port });
const handler = app.getRequestHandler();

const prisma = new PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET || "global-chat-secret-key-2024";

// In-memory store for online users and socket mapping
const onlineUsers = new Map(); // socketId -> { userId, username }
const userSockets = new Map(); // userId -> socketId

app.prepare().then(() => {
  const httpServer = createServer(handler);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"],
    },
    transports: ["websocket", "polling"],
  });

  // Socket.IO middleware for authentication
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token || socket.handshake.query.token;
      if (!token) {
        return next(new Error("Authentication required"));
      }

      const decoded = jwt.verify(token, JWT_SECRET) as { userId: string; username: string; role: string };
      socket.data.user = decoded;
      next();
    } catch (err) {
      next(new Error("Invalid token"));
    }
  });

  io.on("connection", (socket) => {
    const user = socket.data.user;
    if (!user) return;

    console.log(`User connected: ${user.username} (${socket.id})`);

    // Store user connection
    onlineUsers.set(socket.id, {
      userId: user.userId,
      username: user.username,
      role: user.role,
      socketId: socket.id,
    });
    userSockets.set(user.userId, socket.id);

    // Update user online status in database
    prisma.user.update({
      where: { id: user.userId },
      data: { online: true, last_seen: new Date() },
    }).catch(console.error);

    // Broadcast user joined
    socket.broadcast.emit("user:joined", {
      userId: user.userId,
      username: user.username,
    });

    // Send online users list to the new user
    const onlineList = Array.from(onlineUsers.values()).map((u) => ({
      id: u.userId,
      username: u.username,
      online: true,
    }));
    socket.emit("users:online", onlineList);

    // Broadcast updated online count to all
    io.emit("users:count", onlineUsers.size);

    // Handle typing
    socket.on("typing:start", () => {
      socket.broadcast.emit("typing:start", {
        userId: user.userId,
        username: user.username,
      });
    });

    socket.on("typing:stop", () => {
      socket.broadcast.emit("typing:stop", {
        userId: user.userId,
        username: user.username,
      });
    });

    // Handle new message
    socket.on("message:send", async (data) => {
      try {
        const { content, messageType, mediaUrl, replyTo } = data;

        const message = await prisma.message.create({
          data: {
            user_id: user.userId,
            content: content || "",
            message_type: messageType || "text",
            media_url: mediaUrl || null,
            reply_to: replyTo || null,
          },
          include: {
            user: {
              select: {
                id: true,
                username: true,
                avatar: true,
                status: true,
                online: true,
              },
            },
            reactions: {
              include: {
                user: {
                  select: {
                    id: true,
                    username: true,
                  },
                },
              },
            },
          },
        });

        // Broadcast to all clients including sender
        io.emit("message:new", message);

        // Create notifications for offline users
        const offlineUsers = await prisma.user.findMany({
          where: { online: false, id: { not: user.userId } },
          select: { id: true },
        });

        for (const offlineUser of offlineUsers) {
          await prisma.notification.create({
            data: {
              user_id: offlineUser.id,
              message_id: message.id,
              type: "new_message",
              content: `${user.username}: ${content?.slice(0, 50) || "Sent a message"}`,
            },
          });
        }
      } catch (error) {
        console.error("Message send error:", error);
        socket.emit("message:error", { error: "Failed to send message" });
      }
    });

    // Handle message reaction
    socket.on("message:react", async (data) => {
      try {
        const { messageId, emoji } = data;

        // Check if reaction exists
        const existing = await prisma.reaction.findFirst({
          where: {
            message_id: messageId,
            user_id: user.userId,
            emoji,
          },
        });

        if (existing) {
          // Remove reaction (toggle off)
          await prisma.reaction.delete({
            where: { id: existing.id },
          });
        } else {
          // Add reaction
          await prisma.reaction.create({
            data: {
              message_id: messageId,
              user_id: user.userId,
              emoji,
            },
          });
        }

        // Get updated message with reactions
        const updatedMessage = await prisma.message.findUnique({
          where: { id: messageId },
          include: {
            user: {
              select: {
                id: true,
                username: true,
                avatar: true,
                status: true,
                online: true,
              },
            },
            reactions: {
              include: {
                user: {
                  select: {
                    id: true,
                    username: true,
                  },
                },
              },
            },
          },
        });

        io.emit("message:updated", updatedMessage);
      } catch (error) {
        console.error("Reaction error:", error);
      }
    });

    // Handle message delete
    socket.on("message:delete", async (data) => {
      try {
        const { messageId } = data;

        const message = await prisma.message.findUnique({
          where: { id: messageId },
        });

        if (!message) return;

        // Only allow deleting own messages or admin
        if (message.user_id !== user.userId && user.role !== "admin") {
          socket.emit("message:error", { error: "Not authorized" });
          return;
        }

        await prisma.message.update({
          where: { id: messageId },
          data: { deleted_at: new Date() },
        });

        io.emit("message:deleted", { messageId });
      } catch (error) {
        console.error("Delete error:", error);
      }
    });

    // Handle disconnect
    socket.on("disconnect", async () => {
      console.log(`User disconnected: ${user.username} (${socket.id})`);

      onlineUsers.delete(socket.id);
      userSockets.delete(user.userId);

      // Update user offline status
      await prisma.user.update({
        where: { id: user.userId },
        data: { online: false, last_seen: new Date() },
      });

      socket.broadcast.emit("user:left", {
        userId: user.userId,
        username: user.username,
      });

      io.emit("users:count", onlineUsers.size);
    });
  });

  httpServer
    .once("error", (err) => {
      console.error(err);
      process.exit(1);
    })
    .listen(port, () => {
      console.log(`> Ready on http://${hostname}:${port}`);
      console.log(`> Socket.IO server running`);
    });
});

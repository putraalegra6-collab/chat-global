import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { verifyToken } from './lib/auth';

export function middleware(request: NextRequest) {
  const token = request.cookies.get('token')?.value;
  const authHeader = request.headers.get('authorization');
  const jwt = token || (authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null);

  const isAuthPage = request.nextUrl.pathname.startsWith('/login') || 
                     request.nextUrl.pathname.startsWith('/register');
  const isProtected = request.nextUrl.pathname.startsWith('/chat') || 
                      request.nextUrl.pathname.startsWith('/profile') ||
                      request.nextUrl.pathname.startsWith('/admin');

  if (isProtected && !jwt) {
    return NextResponse.redirect(new URL('/login', request.url));
  }

  if (isAuthPage && jwt) {
    try {
      const valid = verifyToken(jwt);
      if (valid) return NextResponse.redirect(new URL('/chat', request.url));
    } catch {}
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico|uploads).*)'],
};

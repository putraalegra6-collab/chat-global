'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useSocket } from '@/hooks/useSocket';
import MessageBubble from './MessageBubble';
import MessageInput from './MessageInput';
import { format } from 'date-fns';

interface ChatRoomProps {
  user: any;
}

export default function ChatRoom({ user }: ChatRoomProps) {
  const [messages, setMessages] = useState<any[]>([]);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
  const { socket, connected, onlineCount, sendMessage, deleteMessage, reactToMessage, startTyping, stopTyping } = useSocket(token);

  useEffect(() => {
    fetch('/api/messages').then(r => r.json()).then(d => {
      setMessages(d.messages || []);
      setLoading(false);
    });
  }, []);

  useEffect(() => {
    if (!socket) return;
    const onNew = (m: any) => setMessages(prev => prev.find(x => x.id === m.id) ? prev : [...prev, m]);
    const onUpd = (m: any) => setMessages(prev => prev.map(x => x.id === m.id ? m : x));
    const onDel = ({ messageId }: any) => setMessages(prev => prev.filter(x => x.id !== messageId));
    const onTypeStart = ({ username }: any) => setTypingUsers(prev => prev.includes(username) ? prev : [...prev, username]);
    const onTypeStop = ({ username }: any) => setTypingUsers(prev => prev.filter(u => u !== username));

    socket.on('message:new', onNew);
    socket.on('message:updated', onUpd);
    socket.on('message:deleted', onDel);
    socket.on('typing:start', onTypeStart);
    socket.on('typing:stop', onTypeStop);
    return () => {
      socket.off('message:new', onNew);
      socket.off('message:updated', onUpd);
      socket.off('message:deleted', onDel);
      socket.off('typing:start', onTypeStart);
      socket.off('typing:stop', onTypeStop);
    };
  }, [socket]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = useCallback((content: string, type: string = 'text', mediaUrl?: string, replyTo?: string) => {
    sendMessage({ content, messageType: type, mediaUrl, replyTo });
  }, [sendMessage]);

  const grouped = messages.reduce((groups: any, m) => {
    const date = new Date(m.created_at).toDateString();
    if (!groups[date]) groups[date] = [];
    groups[date].push(m);
    return groups;
  }, {});

  return (
    <div className="flex-1 flex flex-col min-w-0 bg-slate-950">
      <div className="h-16 border-b border-white/5 flex items-center justify-between px-4 sm:px-6">
        <div>
          <h2 className="font-semibold text-white">Global Chat</h2>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className={`w-2 h-2 rounded-full ${connected ? 'bg-green-500' : 'bg-red-500'}`} />
            {connected ? `${onlineCount} users online` : 'Disconnected'}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {loading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex gap-3 animate-pulse">
                <div className="w-8 h-8 rounded-full bg-slate-800" />
                <div className="space-y-2 flex-1">
                  <div className="h-3 w-24 bg-slate-800 rounded" />
                  <div className="h-12 w-3/4 bg-slate-800 rounded-lg" />
                </div>
              </div>
            ))}
          </div>
        ) : messages.length === 0 ? (
          <div className="text-center py-20">
            <h3 className="text-xl font-semibold text-white mb-2">Welcome to Global Chat</h3>
            <p className="text-slate-400">Start a conversation with people around the world.</p>
          </div>
        ) : (
          Object.entries(grouped).map(([date, msgs]: [string, any]) => (
            <div key={date} className="space-y-4">
              <div className="flex items-center justify-center">
                <span className="text-xs text-slate-500 bg-slate-900 px-3 py-1 rounded-full">
                  {format(new Date(date), 'MMMM d, yyyy')}
                </span>
              </div>
              {msgs.map((message: any) => (
                <MessageBubble key={message.id} message={message} isMe={message.user_id === user.id}
                  onDelete={deleteMessage} onReact={reactToMessage} />
              ))}
            </div>
          ))
        )}
        <div ref={messagesEndRef} />

        {typingUsers.length > 0 && (
          <div className="flex items-center gap-2 text-sm text-slate-400 px-12">
            <div className="flex gap-0.5">
              <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
            {typingUsers.join(', ')} {typingUsers.length === 1 ? 'is' : 'are'} typing...
          </div>
        )}
      </div>

      <MessageInput onSend={handleSend} onTypingStart={startTyping} onTypingStop={stopTyping} />
    </div>
  );
}

'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Globe, MessageSquare, User, Shield, LogOut, X, Search } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { getInitials, generateAvatarColor } from '@/lib/utils';

interface SidebarProps {
  user: any;
  onClose?: () => void;
}

export default function Sidebar({ user, onClose }: SidebarProps) {
  const pathname = usePathname();
  const { logout } = useAuth();

  const navItems = [
    { href: '/chat', label: 'Global Chat', icon: MessageSquare },
    { href: '/profile', label: 'Profile', icon: User },
  ];

  if (user.role === 'admin') {
    navItems.push({ href: '/admin', label: 'Admin Panel', icon: Shield });
  }

  return (
    <div className="h-full flex flex-col">
      <div className="h-16 border-b border-white/5 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <Globe className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-white tracking-tight">GLOBAL CHAT</span>
        </div>
        {onClose && (
          <button onClick={onClose} className="lg:hidden p-2 hover:bg-white/5 rounded-lg text-slate-400">
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      <div className="p-4 border-b border-white/5">
        <div className="flex items-center gap-3">
          {user.avatar ? (
            <img src={user.avatar} alt={user.username} className="w-10 h-10 rounded-full bg-slate-800" />
          ) : (
            <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm ${generateAvatarColor(user.username)}`}>
              {getInitials(user.username)}
            </div>
          )}
          <div className="flex-1 min-w-0">
            <p className="font-medium text-white truncate">{user.username}</p>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-green-500" />
              <span className="text-xs text-slate-400">Online</span>
            </div>
          </div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto p-2 space-y-1">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link key={item.href} href={item.href} onClick={onClose}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                isActive ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20' : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}>
              <item.icon className="w-5 h-5" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="p-2 border-t border-white/5">
        <button onClick={logout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-red-400 hover:bg-red-500/10 transition">
          <LogOut className="w-5 h-5" />
          Logout
        </button>
      </div>
    </div>
  );
}

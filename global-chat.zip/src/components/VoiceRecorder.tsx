'use client';

import { useState, useRef, useEffect } from 'react';
import { Square, Play, Trash2, Send } from 'lucide-react';
import { formatDuration } from '@/lib/utils';

interface Props {
  onComplete: (blob: Blob) => void;
  onCancel: () => void;
}

export default function VoiceRecorder({ onComplete, onCancel }: Props) {
  const [recording, setRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const timerRef = useRef<NodeJS.Timeout>();
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => { startRecording(); return () => { if (timerRef.current) clearInterval(timerRef.current); if (audioUrl) URL.revokeObjectURL(audioUrl); }; }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];
      mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        setAudioBlob(blob);
        setAudioUrl(URL.createObjectURL(blob));
        stream.getTracks().forEach(t => t.stop());
      };
      mediaRecorder.start();
      setRecording(true);
      setDuration(0);
      timerRef.current = setInterval(() => setDuration(d => d + 1), 1000);
    } catch { alert('Microphone access denied'); onCancel(); }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setRecording(false);
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const handleSend = () => { if (audioBlob) onComplete(audioBlob); };
  const togglePlay = () => {
    if (!audioRef.current || !audioUrl) return;
    if (playing) audioRef.current.pause(); else audioRef.current.play();
    setPlaying(!playing);
  };

  if (recording) {
    return (
      <div className="flex-1 flex items-center gap-3 bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-2">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <span className="text-red-400 text-sm font-mono">{formatDuration(duration)}</span>
        </div>
        <div className="flex-1" />
        <button onClick={stopRecording} className="p-2 bg-red-600 hover:bg-red-500 rounded-lg text-white transition">
          <Square className="w-4 h-4" />
        </button>
      </div>
    );
  }

  if (audioUrl) {
    return (
      <div className="flex-1 flex items-center gap-3 bg-slate-950 border border-white/10 rounded-xl px-4 py-2">
        <audio ref={audioRef} src={audioUrl} onEnded={() => setPlaying(false)} className="hidden" />
        <button onClick={togglePlay} className="p-2 bg-blue-600/20 hover:bg-blue-600/30 rounded-lg text-blue-400 transition">
          {playing ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
        </button>
        <span className="text-sm text-slate-400">{formatDuration(duration)}</span>
        <div className="flex-1" />
        <button onClick={onCancel} className="p-2 hover:bg-white/5 rounded-lg text-slate-400 hover:text-red-400 transition">
          <Trash2 className="w-4 h-4" />
        </button>
        <button onClick={handleSend} className="p-2 bg-blue-600 hover:bg-blue-500 rounded-lg text-white transition">
          <Send className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return null;
}

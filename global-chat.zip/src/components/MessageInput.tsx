'use client';

import { useState, useRef, useCallback } from 'react';
import { Send, Paperclip, Mic, X, Video } from 'lucide-react';
import VoiceRecorder from './VoiceRecorder';
import { compressImage } from '@/lib/utils';

interface Props {
  onSend: (content: string, type?: string, mediaUrl?: string, replyTo?: string) => void;
  onTypingStart: () => void;
  onTypingStop: () => void;
}

export default function MessageInput({ onSend, onTypingStart, onTypingStop }: Props) {
  const [text, setText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [previewFile, setPreviewFile] = useState<{ url: string; type: string; name: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout>();

  const handleTyping = useCallback(() => {
    onTypingStart();
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => onTypingStop(), 2000);
  }, [onTypingStart, onTypingStop]);

  const handleSend = () => {
    if (!text.trim() && !previewFile) return;
    onSend(text.trim(), previewFile?.type || 'text', previewFile?.url);
    setText('');
    setPreviewFile(null);
    onTypingStop();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 50 * 1024 * 1024) { alert('File too large. Max 50MB.'); return; }
    setUploading(true);
    try {
      let uploadFile = file;
      if (file.type.startsWith('image/') && !file.type.includes('gif')) {
        uploadFile = new File([await compressImage(file)], file.name, { type: 'image/jpeg' });
      }
      const formData = new FormData();
      formData.append('file', uploadFile);
      formData.append('type', file.type);
      const res = await fetch('/api/upload', { method: 'POST', body: formData, credentials: 'include' });
      const data = await res.json();
      if (data.success) setPreviewFile({ url: data.url, type: data.type, name: data.name });
      else alert(data.error || 'Upload failed');
    } catch { alert('Upload failed'); }
    finally { setUploading(false); if (fileInputRef.current) fileInputRef.current.value = ''; }
  };

  const handleVoiceRecorded = (blob: Blob) => {
    const formData = new FormData();
    formData.append('file', blob, 'voice-note.webm');
    formData.append('type', 'audio/webm');
    fetch('/api/upload', { method: 'POST', body: formData, credentials: 'include' })
      .then(r => r.json()).then(data => { if (data.success) onSend('Voice message', 'audio', data.url); });
  };

  return (
    <div className="border-t border-white/5 bg-slate-900/50 p-3 sm:p-4">
      {previewFile && (
        <div className="mb-3 p-3 bg-slate-800/50 rounded-xl border border-white/5 flex items-center gap-3">
          {previewFile.type === 'image' ? (
            <img src={previewFile.url} alt="" className="w-12 h-12 rounded-lg object-cover" />
          ) : previewFile.type === 'video' ? (
            <Video className="w-12 h-12 text-blue-400" />
          ) : (
            <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <Mic className="w-5 h-5 text-blue-400" />
            </div>
          )}
          <div className="flex-1 min-w-0">
            <p className="text-sm text-white truncate">{previewFile.name}</p>
            <p className="text-xs text-slate-400 capitalize">{previewFile.type} ready to send</p>
          </div>
          <button onClick={() => setPreviewFile(null)} className="p-1.5 hover:bg-white/5 rounded-lg text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      <div className="flex items-end gap-2">
        <input type="file" ref={fileInputRef} onChange={handleFileSelect}
          accept="image/*,video/mp4,video/webm,video/quicktime" className="hidden" />
        <button onClick={() => fileInputRef.current?.click()} disabled={uploading || isRecording}
          className="p-2.5 hover:bg-white/5 rounded-xl text-slate-400 hover:text-white transition disabled:opacity-50">
          <Paperclip className="w-5 h-5" />
        </button>

        {isRecording ? (
          <VoiceRecorder onComplete={(blob) => { handleVoiceRecorded(blob); setIsRecording(false); }} onCancel={() => setIsRecording(false)} />
        ) : (
          <div className="flex-1 flex items-end gap-2 bg-slate-950 border border-white/10 rounded-xl px-3 py-2 focus-within:ring-2 focus-within:ring-blue-500/30 focus-within:border-blue-500/50 transition">
            <textarea value={text} onChange={(e) => { setText(e.target.value); handleTyping(); }} onKeyDown={handleKeyDown}
              placeholder="Type a message..." rows={1}
              className="flex-1 bg-transparent text-white placeholder:text-slate-500 resize-none outline-none text-sm py-1.5 max-h-32"
              style={{ minHeight: '24px' }} />
            <button onClick={() => setIsRecording(true)} className="p-1.5 hover:bg-white/5 rounded-lg text-slate-400 hover:text-white transition">
              <Mic className="w-5 h-5" />
            </button>
          </div>
        )}

        <button onClick={handleSend} disabled={(!text.trim() && !previewFile) || uploading}
          className="p-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl text-white transition shadow-lg shadow-blue-600/20">
          <Send className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}

'use client';

import { useState } from 'react';
import { MoreHorizontal, Copy, Trash2, Heart, Laugh, ThumbsUp, Surprise, Frown, Flame } from 'lucide-react';
import { formatTime, getInitials, generateAvatarColor } from '@/lib/utils';

const REACTIONS = ['❤️','😂','👍','😮','😢','🔥'];

interface Props {
  message: any;
  isMe: boolean;
  onDelete: (id: string) => void;
  onReact: (id: string, emoji: string) => void;
}

export default function MessageBubble({ message, isMe, onDelete, onReact }: Props) {
  const [showMenu, setShowMenu] = useState(false);
  const [showReactions, setShowReactions] = useState(false);
  if (message.deleted_at) return null;

  const user = message.user || {};
  const isEdited = !!message.edited_at;
  const reactionCounts = message.reactions?.reduce((acc: any, r: any) => {
    acc[r.emoji] = (acc[r.emoji] || 0) + 1;
    return acc;
  }, {}) || {};

  return (
    <div className={`flex gap-3 group ${isMe ? 'flex-row-reverse' : ''}`}>
      <div className="flex-shrink-0">
        {user.avatar ? (
          <img src={user.avatar} alt={user.username} className="w-8 h-8 rounded-full bg-slate-800" />
        ) : (
          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold ${generateAvatarColor(user.username || 'U')}`}>
            {getInitials(user.username || 'U')}
          </div>
        )}
      </div>

      <div className={`flex-1 min-w-0 ${isMe ? 'items-end' : 'items-start'} flex flex-col`}>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-sm font-medium text-slate-300">{user.username}</span>
          <span className="text-xs text-slate-500">{formatTime(message.created_at)}</span>
          {isEdited && <span className="text-xs text-slate-600">(edited)</span>}
        </div>

        <div className={`relative max-w-[80%] sm:max-w-[70%] rounded-2xl px-4 py-2.5 ${
          isMe ? 'bg-blue-600 text-white rounded-tr-sm' : 'bg-slate-800 text-slate-200 rounded-tl-sm'
        }`}>
          {message.media_url && message.message_type === 'image' && (
            <img src={message.media_url} alt="Shared" className="rounded-lg max-w-full mb-2 cursor-pointer hover:opacity-90 transition"
              onClick={() => window.open(message.media_url, '_blank')} />
          )}
          {message.media_url && message.message_type === 'video' && (
            <video src={message.media_url} controls className="rounded-lg max-w-full mb-2" preload="metadata" />
          )}
          {message.media_url && message.message_type === 'audio' && (
            <audio src={message.media_url} controls className="w-full mb-2" />
          )}
          {message.content && <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{message.content}</p>}

          {Object.keys(reactionCounts).length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {Object.entries(reactionCounts).map(([emoji, count]) => (
                <button key={emoji} onClick={() => onReact(message.id, emoji)}
                  className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-black/20 text-xs hover:bg-black/30 transition">
                  <span>{emoji}</span><span>{count as number}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center">
        <div className="relative">
          <button onClick={() => setShowMenu(!showMenu)} className="p-1.5 hover:bg-white/5 rounded-lg text-slate-400 hover:text-white">
            <MoreHorizontal className="w-4 h-4" />
          </button>
          {showMenu && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setShowMenu(false)} />
              <div className="absolute right-0 bottom-full mb-1 w-40 bg-slate-900 border border-white/10 rounded-lg shadow-xl py-1 z-20">
                <button onClick={() => { navigator.clipboard.writeText(message.content); setShowMenu(false); }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-slate-300 hover:bg-white/5">
                  <Copy className="w-4 h-4" /> Copy
                </button>
                <button onClick={() => setShowReactions(!showReactions)}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-slate-300 hover:bg-white/5">
                  <Heart className="w-4 h-4" /> React
                </button>
                {isMe && (
                  <button onClick={() => { onDelete(message.id); setShowMenu(false); }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-400 hover:bg-red-500/10">
                    <Trash2 className="w-4 h-4" /> Delete
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      </div>

      {showReactions && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50" onClick={() => setShowReactions(false)}>
          <div className="bg-slate-900 border border-white/10 rounded-2xl p-4 flex gap-2 shadow-2xl" onClick={e => e.stopPropagation()}>
            {REACTIONS.map(emoji => (
              <button key={emoji} onClick={() => { onReact(message.id, emoji); setShowReactions(false); setShowMenu(false); }}
                className="w-10 h-10 flex items-center justify-center text-xl hover:bg-white/10 rounded-xl transition hover:scale-110">
                {emoji}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

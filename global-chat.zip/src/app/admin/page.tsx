'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/hooks/useAuth';
import { Shield, Users, MessageSquare, AlertTriangle, Ban, CheckCircle, Trash2, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { formatDate } from '@/lib/utils';

export default function AdminPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [data, setData] = useState<any>(null);
  const [fetching, setFetching] = useState(true);

  useEffect(() => {
    if (!loading && (!user || user.role !== 'admin')) router.push('/chat');
  }, [user, loading, router]);

  useEffect(() => {
    if (user?.role === 'admin') {
      fetch('/api/admin', { credentials: 'include' })
        .then(r => r.json())
        .then(d => { setData(d); setFetching(false); });
    }
  }, [user]);

  const handleAction = async (action: string, payload: any) => {
    await fetch('/api/admin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...payload }),
      credentials: 'include',
    });
    // Refresh
    const r = await fetch('/api/admin', { credentials: 'include' });
    const d = await r.json();
    setData(d);
  };

  if (loading || fetching) return <div className="min-h-screen bg-slate-950 flex items-center justify-center text-white">Loading...</div>;
  if (!user || user.role !== 'admin') return null;

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <Link href="/chat" className="inline-flex items-center gap-2 text-slate-400 hover:text-white mb-8 transition">
          <ArrowLeft className="w-4 h-4" /> Back to Chat
        </Link>

        <div className="flex items-center gap-3 mb-8">
          <Shield className="w-8 h-8 text-blue-400" />
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Users', value: data?.stats?.totalUsers || 0, icon: Users, color: 'text-blue-400' },
            { label: 'Messages', value: data?.stats?.totalMessages || 0, icon: MessageSquare, color: 'text-green-400' },
            { label: 'Online Now', value: data?.stats?.onlineUsers || 0, icon: Users, color: 'text-emerald-400' },
            { label: 'Pending Reports', value: data?.stats?.pendingReports || 0, icon: AlertTriangle, color: 'text-red-400' },
          ].map(s => (
            <div key={s.label} className="bg-slate-900/50 border border-white/10 rounded-xl p-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-400 text-sm">{s.label}</span>
                <s.icon className={`w-5 h-5 ${s.color}`} />
              </div>
              <p className="text-2xl font-bold">{s.value}</p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Recent Users */}
          <div className="bg-slate-900/50 border border-white/10 rounded-xl p-5">
            <h2 className="text-lg font-semibold mb-4">Recent Users</h2>
            <div className="space-y-3 max-h-80 overflow-y-auto">
              {data?.recentUsers?.map((u: any) => (
                <div key={u.id} className="flex items-center justify-between p-3 bg-slate-950/50 rounded-lg">
                  <div className="flex items-center gap-3">
                    {u.avatar ? <img src={u.avatar} alt="" className="w-8 h-8 rounded-full" /> : <div className="w-8 h-8 rounded-full bg-blue-600" />}
                    <div>
                      <p className="text-sm font-medium">{u.username}</p>
                      <p className="text-xs text-slate-500 capitalize">{u.role}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {u.role !== 'banned' ? (
                      <button onClick={() => handleAction('ban_user', { userId: u.id })}
                        className="p-1.5 hover:bg-red-500/10 rounded-lg text-red-400" title="Ban">
                        <Ban className="w-4 h-4" />
                      </button>
                    ) : (
                      <button onClick={() => handleAction('unban_user', { userId: u.id })}
                        className="p-1.5 hover:bg-green-500/10 rounded-lg text-green-400" title="Unban">
                        <CheckCircle className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Reports */}
          <div className="bg-slate-900/50 border border-white/10 rounded-xl p-5">
            <h2 className="text-lg font-semibold mb-4">Pending Reports</h2>
            <div className="space-y-3 max-h-80 overflow-y-auto">
              {data?.recentReports?.length === 0 && <p className="text-slate-500 text-sm">No pending reports</p>}
              {data?.recentReports?.map((r: any) => (
                <div key={r.id} className="p-3 bg-slate-950/50 rounded-lg">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm"><span className="text-slate-400">Reported by:</span> {r.reporter?.username}</p>
                      {r.reported_user && <p className="text-sm"><span className="text-slate-400">User:</span> {r.reported_user.username}</p>}
                      <p className="text-sm text-slate-300 mt-1">{r.reason}</p>
                      <p className="text-xs text-slate-500 mt-1">{formatDate(r.created_at)}</p>
                    </div>
                    <div className="flex gap-1">
                      {r.message_id && (
                        <button onClick={() => handleAction('delete_message', { messageId: r.message_id })}
                          className="p-1.5 hover:bg-red-500/10 rounded-lg text-red-400" title="Delete Message">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                      <button onClick={() => handleAction('resolve_report', { reportId: r.id })}
                        className="p-1.5 hover:bg-green-500/10 rounded-lg text-green-400" title="Resolve">
                        <CheckCircle className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

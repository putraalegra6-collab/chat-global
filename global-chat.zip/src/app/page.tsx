'use client';

import Link from 'next/link';
import { Globe, MessageCircle, Shield, Zap, Users, Image, Mic, Video } from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white">
      <nav className="border-b border-white/10 backdrop-blur-xl bg-black/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
              <Globe className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight">GLOBAL CHAT</span>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/login" className="text-sm text-slate-300 hover:text-white transition">Sign In</Link>
            <Link href="/register" className="text-sm bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg font-medium transition">Create Account</Link>
          </div>
        </div>
      </nav>

      <section className="pt-20 pb-32 px-4">
        <div className="max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-sm mb-8">
            <Zap className="w-4 h-4" />
            Real-time global messaging
          </div>
          <h1 className="text-5xl sm:text-7xl font-bold tracking-tight mb-6 bg-gradient-to-r from-white via-blue-100 to-slate-400 bg-clip-text text-transparent">
            Connect With The World.
          </h1>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed">
            Chat, share photos, videos, and voice notes with people around the world. Secure, fast, and beautifully designed.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/register" className="w-full sm:w-auto bg-blue-600 hover:bg-blue-500 text-white px-8 py-3.5 rounded-xl font-semibold text-lg transition shadow-lg shadow-blue-600/25">
              Get Started Free
            </Link>
            <Link href="/login" className="w-full sm:w-auto bg-white/5 hover:bg-white/10 border border-white/10 text-white px-8 py-3.5 rounded-xl font-semibold text-lg transition">
              Sign In
            </Link>
          </div>
        </div>
      </section>

      <section className="py-24 border-t border-white/5 bg-slate-950/50">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: MessageCircle, title: 'Real-time Chat', desc: 'Instant messaging with zero delay using WebSocket technology.' },
              { icon: Image, title: 'Media Sharing', desc: 'Share photos, videos, and GIFs with compression and preview.' },
              { icon: Mic, title: 'Voice Notes', desc: 'Record and send voice messages with waveform visualization.' },
              { icon: Shield, title: 'Secure', desc: 'Passwords hashed with bcrypt and HTTPS-only connections.' },
              { icon: Users, title: 'Global Community', desc: 'See who is online and connect with users worldwide.' },
              { icon: Video, title: 'Video Player', desc: 'Built-in video player with controls and fullscreen support.' },
            ].map((f) => (
              <div key={f.title} className="p-6 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-white/10 transition">
                <f.icon className="w-8 h-8 text-blue-400 mb-4" />
                <h3 className="text-lg font-semibold mb-2">{f.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

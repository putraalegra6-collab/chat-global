import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getAuthUser, hashPassword, verifyPassword } from '@/lib/auth';

export async function PATCH(request: NextRequest) {
  try {
    const auth = getAuthUser(request);
    if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await request.json();
    const { username, bio, status, currentPassword, newPassword } = body;
    const updateData: any = {};

    if (bio !== undefined) updateData.bio = bio;
    if (status !== undefined) updateData.status = status;

    if (username && username !== auth.username) {
      const existing = await prisma.user.findUnique({ where: { username: username.toLowerCase() } });
      if (existing) return NextResponse.json({ error: 'Username already taken' }, { status: 409 });
      updateData.username = username.toLowerCase();
    }

    if (newPassword) {
      if (!currentPassword) return NextResponse.json({ error: 'Current password required' }, { status: 400 });
      const user = await prisma.user.findUnique({ where: { id: auth.userId } });
      if (!user || !(await verifyPassword(currentPassword, user.password_hash))) {
        return NextResponse.json({ error: 'Current password incorrect' }, { status: 401 });
      }
      updateData.password_hash = await hashPassword(newPassword);
    }

    const updated = await prisma.user.update({
      where: { id: auth.userId },
      data: updateData,
      select: { id: true, username: true, avatar: true, bio: true, status: true, online: true, last_seen: true, role: true, created_at: true },
    });

    return NextResponse.json({ success: true, user: updated });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

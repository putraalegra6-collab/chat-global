import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getAuthUser } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const auth = getAuthUser(request);
    if (!auth) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { reportedUserId, messageId, reason } = await request.json();

    if (!reason || reason.trim().length < 5) {
      return NextResponse.json(
        { error: 'Reason must be at least 5 characters' },
        { status: 400 }
      );
    }

    const report = await prisma.report.create({
      data: {
        reporter_id: auth.userId,
        reported_user_id: reportedUserId || null,
        message_id: messageId || null,
        reason: reason.trim(),
      },
    });

    return NextResponse.json({ success: true, report });
  } catch (error) {
    console.error('Report error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

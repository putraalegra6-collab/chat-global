import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const users = await prisma.user.findMany({
      where: { online: true },
      select: {
        id: true,
        username: true,
        avatar: true,
        status: true,
        online: true,
        last_seen: true,
      },
    });

    return NextResponse.json({ users, count: users.length });
  } catch (error) {
    console.error('Online users error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getAuthUser } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const auth = getAuthUser(request);
    if (!auth) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const query = searchParams.get('q');

    const users = await prisma.user.findMany({
      where: query
        ? {
            username: {
              contains: query.toLowerCase(),
            },
          }
        : {},
      select: {
        id: true,
        username: true,
        avatar: true,
        status: true,
        online: true,
        last_seen: true,
        role: true,
      },
      take: 50,
    });

    return NextResponse.json({ users });
  } catch (error) {
    console.error('Users GET error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

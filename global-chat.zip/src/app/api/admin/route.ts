import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getAuthUser } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const auth = getAuthUser(request);
    if (!auth || auth.role !== 'admin') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const [
      totalUsers,
      totalMessages,
      onlineUsers,
      pendingReports,
      recentUsers,
      recentMessages,
      recentReports,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.message.count({ where: { deleted_at: null } }),
      prisma.user.count({ where: { online: true } }),
      prisma.report.count({ where: { status: 'pending' } }),
      prisma.user.findMany({
        orderBy: { created_at: 'desc' },
        take: 10,
        select: {
          id: true,
          username: true,
          avatar: true,
          role: true,
          online: true,
          created_at: true,
        },
      }),
      prisma.message.findMany({
        where: { deleted_at: null },
        orderBy: { created_at: 'desc' },
        take: 20,
        include: {
          user: {
            select: {
              id: true,
              username: true,
              avatar: true,
            },
          },
        },
      }),
      prisma.report.findMany({
        where: { status: 'pending' },
        orderBy: { created_at: 'desc' },
        take: 20,
        include: {
          reporter: {
            select: { id: true, username: true },
          },
          reported_user: {
            select: { id: true, username: true },
          },
          message: {
            select: { id: true, content: true },
          },
        },
      }),
    ]);

    return NextResponse.json({
      stats: {
        totalUsers,
        totalMessages,
        onlineUsers,
        pendingReports,
      },
      recentUsers,
      recentMessages,
      recentReports,
    });
  } catch (error) {
    console.error('Admin GET error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = getAuthUser(request);
    if (!auth || auth.role !== 'admin') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await request.json();
    const { action, userId, messageId, reportId } = body;

    if (action === 'ban_user' && userId) {
      await prisma.user.update({
        where: { id: userId },
        data: { role: 'banned' },
      });
      return NextResponse.json({ success: true, message: 'User banned' });
    }

    if (action === 'unban_user' && userId) {
      await prisma.user.update({
        where: { id: userId },
        data: { role: 'user' },
      });
      return NextResponse.json({ success: true, message: 'User unbanned' });
    }

    if (action === 'delete_message' && messageId) {
      await prisma.message.update({
        where: { id: messageId },
        data: { deleted_at: new Date() },
      });
      return NextResponse.json({ success: true, message: 'Message deleted' });
    }

    if (action === 'resolve_report' && reportId) {
      await prisma.report.update({
        where: { id: reportId },
        data: { status: 'resolved', resolved_at: new Date() },
      });
      return NextResponse.json({ success: true, message: 'Report resolved' });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    console.error('Admin POST error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/hooks/useAuth';
import { ArrowLeft, Save, Loader2 } from 'lucide-react';
import Link from 'next/link';
import { getInitials, generateAvatarColor, formatDate } from '@/lib/utils';

export default function ProfilePage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [form, setForm] = useState({ username: '', bio: '', status: '', currentPassword: '', newPassword: '' });

  useEffect(() => {
    if (user) setForm({ username: user.username, bio: user.bio || '', status: user.status || '', currentPassword: '', newPassword: '' });
  }, [user]);

  if (loading) return <div className="min-h-screen bg-slate-950 flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-blue-500" /></div>;
  if (!user) { router.push('/login'); return null; }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage('');
    try {
      const res = await fetch('/api/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      setMessage(data.success ? 'Profile updated successfully' : (data.error || 'Update failed'));
    } catch { setMessage('An error occurred'); }
    finally { setSaving(false); }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <Link href="/chat" className="inline-flex items-center gap-2 text-slate-400 hover:text-white mb-8 transition">
          <ArrowLeft className="w-4 h-4" /> Back to Chat
        </Link>

        <div className="bg-slate-900/50 border border-white/10 rounded-2xl p-6 sm:p-8">
          <h1 className="text-2xl font-bold mb-6">Profile Settings</h1>

          {message && (
            <div className={`mb-6 p-3 rounded-lg text-sm ${message.includes('success') ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'}`}>
              {message}
            </div>
          )}

          <div className="flex items-center gap-4 mb-8">
            {user.avatar ? (
              <img src={user.avatar} alt={user.username} className="w-20 h-20 rounded-full bg-slate-800" />
            ) : (
              <div className={`w-20 h-20 rounded-full flex items-center justify-center text-white text-xl font-bold ${generateAvatarColor(user.username)}`}>
                {getInitials(user.username)}
              </div>
            )}
            <div>
              <h2 className="text-lg font-semibold">{user.username}</h2>
              <p className="text-sm text-slate-400">Joined {formatDate(user.created_at)}</p>
              <p className="text-xs text-slate-500 mt-1 capitalize">Role: {user.role}</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">Username</label>
              <input type="text" value={form.username} onChange={e => setForm({...form, username: e.target.value})}
                className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">Status / Bio</label>
              <input type="text" value={form.status} onChange={e => setForm({...form, status: e.target.value})}
                placeholder="What's on your mind?"
                className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2.5 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">About</label>
              <textarea value={form.bio} onChange={e => setForm({...form, bio: e.target.value})} rows={3}
                className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2.5 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 resize-none" />
            </div>

            <div className="border-t border-white/5 pt-5">
              <h3 className="text-sm font-medium text-slate-300 mb-4">Change Password</h3>
              <div className="space-y-4">
                <input type="password" value={form.currentPassword} onChange={e => setForm({...form, currentPassword: e.target.value})}
                  placeholder="Current password"
                  className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2.5 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50" />
                <input type="password" value={form.newPassword} onChange={e => setForm({...form, newPassword: e.target.value})}
                  placeholder="New password"
                  className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2.5 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50" />
              </div>
            </div>

            <button type="submit" disabled={saving}
              className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-semibold py-2.5 rounded-lg transition flex items-center justify-center gap-2">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              {saving ? 'Saving...' : 'Save Changes'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

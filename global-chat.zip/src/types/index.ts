export interface User {
  id: string;
  username: string;
  avatar?: string | null;
  bio?: string | null;
  status?: string | null;
  online: boolean;
  last_seen: string;
  role: string;
  created_at: string;
}

export interface Message {
  id: string;
  user_id: string;
  user?: User;
  content: string;
  message_type: 'text' | 'image' | 'video' | 'audio';
  media_url?: string | null;
  reply_to?: string | null;
  reply_message?: Message | null;
  created_at: string;
  edited_at?: string | null;
  deleted_at?: string | null;
  reactions?: Reaction[];
  status?: 'sent' | 'delivered' | 'read';
}

export interface Reaction {
  id: string;
  message_id: string;
  user_id: string;
  emoji: string;
  user?: User;
}

export interface Report {
  id: string;
  reporter_id: string;
  reported_user_id?: string;
  message_id?: string;
  reason: string;
  status: string;
  created_at: string;
}

export interface NotificationItem {
  id: string;
  user_id: string;
  message_id?: string;
  type: string;
  content?: string;
  read: boolean;
  created_at: string;
}

export interface OnlineUser {
  id: string;
  username: string;
  avatar?: string;
  status?: string;
  online: boolean;
  last_seen: string;
}

export interface ChatState {
  messages: Message[];
  onlineUsers: OnlineUser[];
  typingUsers: string[];
  unreadCount: number;
}

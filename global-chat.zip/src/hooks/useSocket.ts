'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';

export function useSocket(token: string | null) {
  const socketRef = useRef<Socket | null>(null);
  const [connected, setConnected] = useState(false);
  const [onlineCount, setOnlineCount] = useState(0);

  useEffect(() => {
    if (!token) return;
    const socket = io(typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000', {
      auth: { token },
      transports: ['websocket', 'polling'],
    });
    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));
    socket.on('users:count', (count: number) => setOnlineCount(count));
    socketRef.current = socket;
    return () => { socket.disconnect(); };
  }, [token]);

  const sendMessage = useCallback((data: any) => {
    socketRef.current?.emit('message:send', data);
  }, []);

  const deleteMessage = useCallback((messageId: string) => {
    socketRef.current?.emit('message:delete', { messageId });
  }, []);

  const reactToMessage = useCallback((messageId: string, emoji: string) => {
    socketRef.current?.emit('message:react', { messageId, emoji });
  }, []);

  const startTyping = useCallback(() => {
    socketRef.current?.emit('typing:start');
  }, []);

  const stopTyping = useCallback(() => {
    socketRef.current?.emit('typing:stop');
  }, []);

  return { socket: socketRef.current, connected, onlineCount, sendMessage, deleteMessage, reactToMessage, startTyping, stopTyping };
}
